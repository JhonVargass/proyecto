
<?php
$a="Chrysanthemum.jpg";
echo "<img src='uploads/$a' width='150' height='150' alt='Alargada' border='0'>";

?>